﻿using Serilog;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
        readonly ILogger _logger;

        public $safeitemname$(ILogger logger)
        {
            _logger = logger;
        }
    }
}
